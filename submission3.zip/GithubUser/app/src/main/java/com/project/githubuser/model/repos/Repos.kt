package com.project.githubuser.model.repos


data class Repos(
    val name: String,
    val description: String,
)
