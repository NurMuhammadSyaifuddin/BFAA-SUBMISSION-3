package com.project.githubuser.model.user

data class UserResponse(
    val items: MutableList<User>
)
